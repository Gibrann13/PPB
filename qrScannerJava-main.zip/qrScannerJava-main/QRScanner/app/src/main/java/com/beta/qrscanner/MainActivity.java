package com.beta.qrscanner;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.hanks.passcodeview.PasscodeView;

public class MainActivity extends AppCompatActivity {
    Button btnScanBarcode;
    EditText resultText;
    EditText HasilTotal;
    int dummy;
    private Button openButton;
    private Button backPayment;
    private PasscodeView passcodeView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnScanBarcode = findViewById(R.id.btnScanBarcode);
        resultText = findViewById(R.id.result_text);
        HasilTotal = findViewById(R.id.HasilTotal);
        openButton = findViewById(R.id.btnConfirmBayar);


        btnScanBarcode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, ScannedBarcodeActivity.class);
                scanBarcodeLauncher.launch(intent);
            }
        });

        openButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, PinReqActivity.class);
                intent.putExtra("dummyValue", dummy);
                startActivity(intent); // Memulai PinReqActivity
            }
        });


//        openButton.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                // Initialize passcode view logic
//                PasscodeView passcodeView = findViewById(R.id.passcodeview);
//                PasscodeLogic.initializePasscodeView(MainActivity.this, passcodeView);
//            }
//        });


    }

    private int performSubtraction(String value) {
        int intValue = Integer.parseInt(value);
        return 1000000 - intValue ;
    }

    private ActivityResultLauncher<Intent> scanBarcodeLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == RESULT_OK) {
                    Intent data = result.getData();
                    if (data != null && data.hasExtra("intentData")) {
                        String intentData = data.getStringExtra("intentData");
                        resultText.setText(intentData);

                        dummy = performSubtraction(intentData);

                        HasilTotal.setText(String.valueOf(dummy));
                    }
                }
            });


}
