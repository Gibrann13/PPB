//package com.beta.qrscanner;
//
//import android.content.Context;
//import android.content.Intent;
//import android.os.Bundle;
//import android.widget.Toast;
//
//import com.hanks.passcodeview.PasscodeView;
//
//public class PasscodeLogic {
//    public static void initializePasscodeView(Context context, PasscodeView passcodeView) {
//        protected void onCreate(Bundle savedInstanceState) {
//            setContentView(R.layout.pin_req);
//
//        passcodeView.setPasscodeLength(5)
//                .setLocalPasscode("12369")
//                .setListener(new PasscodeView.PasscodeViewListener() {
//                    @Override
//                    public void onFail() {
//                        Toast.makeText(context, "Password is wrong!", Toast.LENGTH_SHORT).show();
//                    }
//
//                    @Override
//                    public void onSuccess(String number) {
//                        Intent intent_passcode = new Intent(context, PinReqActivity.class);
//                        context.startActivity(intent_passcode);
//                    }
//                });
//    }
//}
