package com.example.tubes_e_money

data class MenuGroup(val judul: String, val menuItems: List<String>)