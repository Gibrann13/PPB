package com.example.tubes_e_money

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView


class Home : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.home)

        //Favorite Transaction
        val horizontalRecyclerViewFav = findViewById<RecyclerView>(R.id.horizontalRecyclerViewFavoriteTransaction)
        val itemListFav: MutableList<String> = ArrayList()
        // Tambahkan item ke dalam daftar
        itemListFav.add("Item 1")
        itemListFav.add("Item 2")
        itemListFav.add("Item 3")
        itemListFav.add("Item 4")

        if (itemListFav.isEmpty()) {
            // Daftar item kosong, lakukan sesuatu di sini jika diperlukan

        } else {
            // Daftar item tidak kosong, kirimkan ke adapter
            val adapter = HorizontalAdapter(itemListFav)
            horizontalRecyclerViewFav.layoutManager =
                LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
            horizontalRecyclerViewFav.adapter = adapter
        }



        //Insight
        val horizontalRecyclerView = findViewById<RecyclerView>(R.id.horizontalRecyclerView)
        val itemList: MutableList<String> = ArrayList()
        // Tambahkan item ke dalam daftar
        itemList.add("Item 1")
        itemList.add("Item 2")
        itemList.add("Item 3")
        itemList.add("Item 4")

        if (itemList.isEmpty()) {
            // Daftar item kosong, lakukan sesuatu di sini jika diperlukan
            Toast.makeText(this, "Daftar item kosong", Toast.LENGTH_SHORT).show()
        } else {
            // Daftar item tidak kosong, kirimkan ke adapter
            val adapter = HorizontalAdapter(itemList)
            horizontalRecyclerView.layoutManager =
                LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
            horizontalRecyclerView.adapter = adapter
        }

    }
}