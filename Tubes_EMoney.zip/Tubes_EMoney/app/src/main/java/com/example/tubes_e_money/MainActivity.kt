package com.example.tubes_e_money

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.Toast
import androidx.navigation.findNavController
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.setupActionBarWithNavController
import androidx.navigation.ui.setupWithNavController
import com.example.tubes_e_money.Profile
import com.google.android.material.bottomnavigation.BottomNavigationView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
//
//        var intent = Intent(this, MainActivity::class.java)
//        startActivity(intent)

        val bottomNavigation: BottomNavigationView = findViewById(R.id.bot_nav)

        val navController = findNavController(R.id.nav_host_fragment)

        val appBarConfiguration = AppBarConfiguration.Builder(
            R.id.navigation_home,
            R.id.navigation_profile).build()

        setupActionBarWithNavController(navController, appBarConfiguration)
        bottomNavigation.setupWithNavController(navController)

//        bottomNavigation.setOnItemSelectedListener { menuItem ->
//            when (menuItem.itemId) {
//                R.id.home_menu -> {
//                    // Tindakan yang diambil saat menu "Home" dipilih
//                    // Contoh: Pindah ke fragmen dengan ID navigation_home
////                    findNavController(R.id.nav_host_fragment).navigate(R.id.navigation_home)
//                    true
//                }
////                R.id.account_menu -> {
////                    // Tindakan yang diambil saat menu "Profile" dipilih
////                    // Contoh: Pindah ke fragmen dengan ID navigation_profile
////                    findNavController(R.id.nav_host_fragment).navigate(R.id.navigation_profile)
////                    true
////                }
//                // Tambahkan kasus lainnya untuk setiap item menu lainnya di sini
//                else -> false
//            }
//        }

    }

    private fun showToast(message: String) {
        Toast.makeText(this@MainActivity, message, Toast.LENGTH_SHORT).show()
    }



}