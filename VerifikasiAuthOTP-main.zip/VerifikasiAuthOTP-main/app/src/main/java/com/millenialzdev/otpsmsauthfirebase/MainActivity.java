package com.millenialzdev.otpsmsauthfirebase;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button
import com.google.firebase.auth.FirebaseAuth;
import android.content.Intent

public class MainActivity extends AppCompatActivity {
    private lateinit var auth: FirebaseAuth
    private lateinit var signOutBtn: Button

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        FirebaseAuth auth = FirebaseAuth.getInstance();
        View signOutBtn = findViewById(R.id.signOutBtn);

        signOutBtn.setOnClickListener {
            auth.signOut()
            startActivity(Intent(this, PhoneActivity::class.java))
        }
    }
}